// Client-side module entry point.
console.info('Ashkan CMS starter module loaded');
