// Add your browser-side plugin behavior here.
console.info('Ashkan CMS starter plugin loaded');
